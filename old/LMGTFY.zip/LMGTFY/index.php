<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en">
<head>

	<title>Let me google that for you</title>

	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	<meta http-equiv="ImageToolbar" content="No" />
	<meta name="MSSmartTagsPreventParsing" content="True" />
	<meta http-equiv="Expires" content="0" />
	<meta http-equiv="Pragma" content="No-Cache" />
	<meta http-equiv="Cache-Control" content="No-Cache,Must-Revalidate,No-Store" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta content="For all those people that find it more convenient to bother you with their question rather than google it for themselves." name="description" />
	<meta content="google, search, funny, comedy" name="keywords" />

	<link href="favicon.ico" type="image/x-icon" rel="icon" />
	<link title="LMGTFY" href="lmgtfy.xml" type="application/opensearchdescription+xml" rel="search" />

	<script src="l_files/jquery.min.js" type="text/javascript"></script>
	<script src="l_files/bundle.js" type="text/javascript"></script>
	<script src="l_files/script.js" type="text/javascript"></script>
	
	<link rel="stylesheet" href="l_files/style.css" type="text/css" media="screen" title="stylesheet" />	

</head>
<body>
<center>
<div class="c1">
<div class="logo"><span>let me</span> <img id="logo" src="l_files/logo.png" alt="Logo" /><span>that for you</span></div>
<br />
<br />
<br />

<form>
        <input type="text" value="" title="Google Search" size="55" class="text">
        <br>
        <span class="button_wrapper">
          <div class="inner">
            <input type="button" value="Google Search" rel="localize[search_button]" id="search">
          </div>
        </span>
        <span class="button_wrapper">
          <div class="inner">
            <input type="button" value="I'm Feeling Lucky" rel="localize[lucky_button]" id="lucky">
          </div>
        </span>
      </form>
<div id="instructions">Type a question, click a button.</div></center>
<div id="link_placeholder"></div>
<div id="link"><input class="link copyable" readonly="readonly" />
<div id="link_message"></div>
<div id="link_buttons"><a class="link_button" id="copy" href="/#" rel="localize[link.copy]">copy</a> <a class="link_button" id="reset" href="/#" rel="localize[link.reset]">reset</a> <a class="link_button" id="tiny" href="/#" rel="localize[link.shorten]">tinyurl</a> <a class="link_button" id="go" href="/#" rel="localize[link.go]">go</a></div>
</div>
</div>
<div id="sponsor"><img src="l_files/sponsored_by.png" alt="Sponsored by" /></div>
<div id="footer"><a class="about" href="/#" rel="localize[about]" name="about">About</a> <a href="http://google/" rel="localize[live]">Google</a> <a href="mailto:admin@lmgtfy.me.uk?body=Nice&amp;subject=I%20love%20LMGTFY%21" rel="localize[contact]">Contact</a> <a href="http://goodbyj.co.uk" rel="localize[advertise]">My Homepage</a></div>
<div id="about" class="c2">
<p>This is for all those people that find it more convenient to bother you with their question rather than google it for themselves.</p>
<p>Not associated with Google in any way.</p>
</div>
<div id="copyright"> LMGTFY, 2011 | <span>GOOGLE is a trademark of Google Inc.</span></div>
<img id="fake_mouse" class="c3" src="l_files/mouse_arrow.png" alt="Mouse" />

<script type="text/javascript">
//<![CDATA[
 var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
 document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
//]]>
</script><script src="http://www.google-analytics.com/ga.js" type="text/javascript">
</script><script type="text/javascript">
//<![CDATA[
 try {
 var pageTracker = _gat._getTracker("UA-6370983-1");
 pageTracker._trackPageview();
 } catch(err) {}
//]]>
</script>

</body>
</html>